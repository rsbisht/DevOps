/opt/dragon/SERVER/query/bin/query.sh stop

