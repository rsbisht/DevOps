/opt/dragon/SERVER/loader/bin/loader.sh start

