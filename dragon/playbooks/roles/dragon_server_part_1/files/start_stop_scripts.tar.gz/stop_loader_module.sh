/opt/dragon/SERVER/loader/bin/loader.sh stop

