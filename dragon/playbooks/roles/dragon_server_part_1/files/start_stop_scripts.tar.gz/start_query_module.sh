/opt/dragon/SERVER/query/bin/query.sh start

